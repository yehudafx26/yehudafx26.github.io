% Bilbao, S, Russo, R, Webb, C & Ducceschi, M 2024, 
% Real-time guitar synthesis. 
% in Proceedings of the 27th International Conference on Digital Audio Effects ((DAFx24). 
% Proceedings of the International Conference on Digital Audio Effects, Surrey, UK, pp. 163-170.
% gradiant restraint by scaling in Section 4.7

function [G] = gradientScale(Gtilde, Gtilde_prev, chiprev, rfree)

    G      = Gtilde;
    gamma  = 1;
    caseID = 0;

    val = 4*chiprev + G*rfree;

    if val < 0

        xi = Gtilde.' * rfree;
        xiPrev = Gtilde_prev.' * rfree;
        if abs(xi)>0 && xi<-4*chiprev
            gamma = -4*chiprev / xi;
            caseID = 1;
            G = Gtilde*gamma;
        elseif abs(xi)==0 && abs(xiPrev)>0
            gamma = -4*chiprev / xiPrev;

            if -4*chiprev/xiPrev<0
                lamda = 1.5;
            else 
                lamda = 0.5;
            end

            lamda = 1;

            caseID = 2;
            G = Gtilde_prev*gamma*lamda;

        else
            gamma = 1;
            caseID = 0;
            G = Gtilde*gamma;
        end
        

    end

end
