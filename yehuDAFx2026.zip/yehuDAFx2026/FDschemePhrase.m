clear all;
close all;

%% AUDIO AND VIDEOWRITE
audioWrite = 1;
aniPlot = 0;
ges_num = 0;

SR = 44100;

%% CHOOSE PHRASES
% 1->6
for i = 1

num = i;

[fn, vb, xf, ff] = playPhrases(SR, num);

%% NUMERICAL SIMULATION
[fStringParams, cStringParams, bodyParams, fingerParams, ...
    bowParams, frictionParams] = yehuParams();

[out, Fbri, muchi1, muchi2] = yehu(vb, fn, xf, ff, fStringParams, cStringParams, ...
    bodyParams, fingerParams, bowParams, frictionParams, SR, ges_num, aniPlot);


%% AUDIO WRITE

filename_u = sprintf('samples/Phrase%d_u.wav', num);
filename_f = sprintf('samples/Phrase%d_F.wav', num);

if audioWrite == 1
    audiowrite(filename_u, out, SR);
    audiowrite(filename_f, Fbri, SR);
end

end

