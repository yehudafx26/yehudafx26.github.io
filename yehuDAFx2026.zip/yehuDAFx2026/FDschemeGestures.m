clear;
close all;

%% AUDIO AND VIDEOWRITE
audioWrite = 1;
aniPlot = 0;


%% SIMULATION PARAMETERS
SR = 44100;
t = 2;
Nf = ceil (SR * t);

%% GENERATE CONTROL SIGNALS
% 1->5
for i = 1:5

ges_num = i ;
[fn, vb, xf, ff] = playGestures(ges_num, Nf, SR);


%% NUMERICAL SIMULATION
[fStringParams, cStringParams, bodyParams, fingerParams, ...
    bowParams, frictionParams] = yehuParams();

[out, Fbri, muchi1, muchi2] = yehu(vb, fn, xf, ff, fStringParams, cStringParams, ...
    bodyParams, fingerParams, bowParams, frictionParams, SR, ges_num, aniPlot);



%% AUDIO WRITE

if audioWrite == 1

        filename_u = sprintf('ges%d_u.wav', ges_num);
        filepath_u = fullfile('samples', filename_u);

        filename_Fbri = sprintf('ges%d_f.wav', ges_num);
        filepath_f = fullfile('samples', filename_Fbri);

        audiowrite(filepath_u, out, SR);
        audiowrite(filepath_f, Fbri, SR);

end


end