clear;
close all;

SR = 44100;


for i = 1:5

    ges_u = sprintf('ges%d_u.wav', i);

    ub = audioread(ges_u);
    load('recordPosBriVelo.mat');
    fil_ges_u = parfilt(Bm,Am,FIR,ub);
    fil_ges_u = fil_ges_u/max(abs(fil_ges_u));
    fil_ges_u_name = sprintf('fil_Ges%d_u.wav', i);
    audiowrite(fil_ges_u_name, fil_ges_u, SR);

    
    ges_f = sprintf('ges%d_f.wav', i);
    fb = audioread(ges_f);
    load('recordPosition.mat');
    fil_ges_f = parfilt(Bm,Am,FIR,fb);
    fil_ges_f = fil_ges_f/max(abs(fil_ges_f));
    fil_ges_f_name = sprintf('fil_Ges%d_f.wav', i);
    audiowrite(fil_ges_f_name, fil_ges_f, SR);

    load('playerPosition.mat');
    fil_ges_fp = parfilt(Bm,Am,FIR,fb);
    fil_ges_fp = fil_ges_fp/max(abs(fil_ges_fp));
    fil_ges_fp_name = sprintf('fil_Ges%d_fp.wav', i);
    audiowrite(fil_ges_fp_name, fil_ges_fp, SR);

    
end

