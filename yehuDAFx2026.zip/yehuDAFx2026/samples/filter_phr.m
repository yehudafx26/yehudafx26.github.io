clear;
close all;

SR = 44100;


for i = 1:6

    phrase_u = sprintf('Phrase%d_u.wav', i);

    ub = audioread(phrase_u);
    load('recordPosBriVelo.mat');
    fil_phrase_u = parfilt(Bm,Am,FIR,ub);
    fil_phrase_u = fil_phrase_u/max(abs(fil_phrase_u));
    fil_phrase_u_name = sprintf('fil_Phrase%d_u.wav', i);
    audiowrite(fil_phrase_u_name, fil_phrase_u, SR);

    
    phrase_f = sprintf('Phrase%d_F.wav', i);
    fb = audioread(phrase_f);
    load('recordPosition.mat');
    fil_phrase_f = parfilt(Bm,Am,FIR,fb);
    fil_phrase_f = fil_phrase_f/max(abs(fil_phrase_f));
    fil_phrase_f_name = sprintf('fil_Phrase%d_f.wav', i);
    audiowrite(fil_phrase_f_name, fil_phrase_f, SR);

    load('playerPosition.mat');
    fil_phrase_fp = parfilt(Bm,Am,FIR,fb);
    fil_phrase_fp = fil_phrase_fp/max(abs(fil_phrase_fp));
    fil_phrase_fp_name = sprintf('fil_Phrase%d_fp.wav', i);
    audiowrite(fil_phrase_fp_name, fil_phrase_fp, SR);

    
end

